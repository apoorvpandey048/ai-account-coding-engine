Machine Learning - AI-Based Account Coding Service

Summary
We are looking to build a backend AI service that generates general ledger (GL) account coding suggestions for invoice line items. So we need someone who is familiar with developing an AI based product. Any recommendation of the freelancer is welcomed if our idea is not good enough etc.

The document extraction, OCR, and ERP integration already exist.
Our service will receive structured exports of invoice line items and return account coding suggestions via API.



Input (via API):
-Invoice line item text (free text)
-Supplier name / ID
-Quantity
-Unit of measure
-Unit price / line amount
-Optional: product group, PO reference
-Customer-specific chart of accounts (GL accounts)


Output (via API):
-Top 1–3 suggested GL accounts
-Confidence score per suggestion
-Short explanation (why this account was suggested)
-Optional: high-level category (e.g. material, transport, surcharge, service)
-The ERP system will consume the response and write the final booking after user confirmation.


Core Logic
-Semantic classification of invoice line items
(e.g. material, consumables, tools, transport, surcharge, service)
-Mapping of category → chart of accounts
-LLM-based reasoning for cases where rules are insufficient
-Deterministic JSON output (no free-form text responses)
-Initially, the system works without historical training data (zero-shot / rule-assisted LLM).
-User confirmations and corrections are logged for future model training.


Technical Expectations
-Backend service (Python preferred, e.g. FastAPI)
-REST API (/suggest, /feedback)
-Azure-based deployment (Azure Container Apps or App Service)
-Azure OpenAI used for semantic understanding (LLM)
-Structured logging, versioning, and basic monitoring


Outcome
A reusable, licenseable AI Account Coding Engine that can be embedded into existing ERP or DMS workflows and improved over time via feedback.


Further milestones can be set up if needed.

$300.00

Fixed-price
Intermediate
I am looking for a mix of experience and value
Project Type:Ongoing project
Skills and Expertise
Mandatory skills
Python
Machine Learning
Artificial Intelligence
Artificial Neural Network
Data Science