# API Request/Response Schemas - Demo Examples

## Example 1: Material (Pipes & Fittings)

### REQUEST
```json
POST /api/v1/suggest
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_item": {
    "invoice_text": "Streng duct PP-HM Sickerrohr SN4 Ø150mm L5m"
  },
  "top_k": 3
}
```

### RESPONSE
```json
{
  "suggestions": [
    {
      "account": "1220 – Materialvorräte",
      "confidence": 0.98,
      "explanation": "Primary account for category 'Material'"
    },
    {
      "account": "1270 – Angefangene Arbeiten",
      "confidence": 0.539,
      "explanation": "Alternative account for category 'Material'"
    },
    {
      "account": "1200 – Waren",
      "confidence": 0.392,
      "explanation": "Alternative account for category 'Material'"
    }
  ],
  "semantic_category": "Material",
  "classification_confidence": 0.98,
  "classification_method": "hybrid",
  "classification_reasoning": "Rule and LLM agree: Material-related keywords detected",
  "metadata": {
    "invoice_text": "Streng duct PP-HM Sickerrohr SN4 Ø150mm L5m"
  }
}
```

---

## Example 2: Transport Costs

### REQUEST
```json
POST /api/v1/suggest
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_item": {
    "invoice_text": "Transportkosten per LKW nach Zürich"
  },
  "top_k": 3
}
```

### RESPONSE
```json
{
  "suggestions": [
    {
      "account": "4061 – Fremdtransporte",
      "confidence": 0.98,
      "explanation": "Primary account for category 'Transport'"
    },
    {
      "account": "4062 – Deponiegebühren",
      "confidence": 0.539,
      "explanation": "Alternative account for category 'Transport'"
    },
    {
      "account": "1220 – Materialvorräte",
      "confidence": 0.294,
      "explanation": "Fallback account for uncertain classification"
    }
  ],
  "semantic_category": "Transport",
  "classification_confidence": 0.98,
  "classification_method": "hybrid",
  "classification_reasoning": "Rule and LLM agree: Transport-related keywords detected",
  "metadata": {
    "invoice_text": "Transportkosten per LKW nach Zürich"
  }
}
```

---

## Example 3: Surcharge (Energy)

### REQUEST
```json
POST /api/v1/suggest
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_item": {
    "invoice_text": "Energiezuschlag Januar 2026"
  },
  "top_k": 3
}
```

### RESPONSE
```json
{
  "suggestions": [
    {
      "account": "2004 – Verbindlichkeiten übr. Betriebsaufwand",
      "confidence": 0.95,
      "explanation": "Primary account for category 'Surcharge'"
    },
    {
      "account": "4980 – Surcharges & Fees",
      "confidence": 0.522,
      "explanation": "Alternative account for category 'Surcharge'"
    },
    {
      "account": "4900 – Transport & Freight Costs",
      "confidence": 0.38,
      "explanation": "Alternative account for category 'Surcharge'"
    }
  ],
  "semantic_category": "Surcharge",
  "classification_confidence": 0.95,
  "classification_method": "rule",
  "classification_reasoning": "Rule-based classification: Surcharge keyword pattern matched",
  "metadata": {
    "invoice_text": "Energiezuschlag Januar 2026"
  }
}
```

---

## Example 4: External Service (Consulting)

### REQUEST
```json
POST /api/v1/suggest
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_item": {
    "invoice_text": "Beratungsleistung Engineering für Statikberechnung"
  },
  "top_k": 3
}
```

### RESPONSE
```json
{
  "suggestions": [
    {
      "account": "2004 – Verbindlichkeiten übr. Betriebsaufwand",
      "confidence": 0.95,
      "explanation": "Primary account for category 'Service'"
    },
    {
      "account": "2000 – Verbindlichkeiten aus L+L",
      "confidence": 0.522,
      "explanation": "Alternative account for category 'Service'"
    },
    {
      "account": "6000 – External Services",
      "confidence": 0.38,
      "explanation": "Alternative account for category 'Service'"
    }
  ],
  "semantic_category": "Service",
  "classification_confidence": 0.95,
  "classification_method": "rule",
  "classification_reasoning": "Rule-based classification: Service keyword pattern matched",
  "metadata": {
    "invoice_text": "Beratungsleistung Engineering für Statikberechnung"
  }
}
```

---

## Example 5: Consumables (Wire Ties)

### REQUEST
```json
POST /api/v1/suggest
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_item": {
    "invoice_text": "Rapido Drahtbinder geschweisst 12cm 1000St."
  },
  "top_k": 3
}
```

### RESPONSE
```json
{
  "suggestions": [
    {
      "account": "1220 – Materialvorräte",
      "confidence": 0.95,
      "explanation": "Primary account for category 'Consumables'"
    },
    {
      "account": "1540 – Werkzeuge und Geräte",
      "confidence": 0.522,
      "explanation": "Alternative account for category 'Consumables'"
    }
  ],
  "semantic_category": "Consumables",
  "classification_confidence": 0.95,
  "classification_method": "rule",
  "classification_reasoning": "Rule-based classification: Consumables keyword pattern matched",
  "metadata": {
    "invoice_text": "Rapido Drahtbinder geschweisst 12cm 1000St."
  }
}
```

---

## Batch Request Example

### REQUEST
```json
POST /api/v1/suggest/batch
Content-Type: application/json
X-API-Key: dev-key-001

{
  "line_items": [
    {
      "invoice_text": "Streng duct PP-HM Sickerrohr SN4 Ø150mm L5m"
    },
    {
      "invoice_text": "Transportkosten per LKW nach Zürich"
    },
    {
      "invoice_text": "Energiezuschlag Januar 2026"
    }
  ],
  "top_k": 3
}
```

### RESPONSE
```json
{
  "results": [
    {
      "suggestions": [
        {
          "account": "1220 – Materialvorräte",
          "confidence": 0.98,
          "explanation": "Primary account for category 'Material'"
        },
        {
          "account": "1270 – Angefangene Arbeiten",
          "confidence": 0.539,
          "explanation": "Alternative account for category 'Material'"
        },
        {
          "account": "1200 – Waren",
          "confidence": 0.392,
          "explanation": "Alternative account for category 'Material'"
        }
      ],
      "semantic_category": "Material",
      "classification_confidence": 0.98,
      "classification_method": "hybrid",
      "classification_reasoning": "Rule and LLM agree: Material-related keywords detected",
      "metadata": {
        "invoice_text": "Streng duct PP-HM Sickerrohr SN4 Ø150mm L5m"
      }
    },
    {
      "suggestions": [
        {
          "account": "4061 – Fremdtransporte",
          "confidence": 0.98,
          "explanation": "Primary account for category 'Transport'"
        },
        {
          "account": "4062 – Deponiegebühren",
          "confidence": 0.539,
          "explanation": "Alternative account for category 'Transport'"
        },
        {
          "account": "1220 – Materialvorräte",
          "confidence": 0.294,
          "explanation": "Fallback account for uncertain classification"
        }
      ],
      "semantic_category": "Transport",
      "classification_confidence": 0.98,
      "classification_method": "hybrid",
      "classification_reasoning": "Rule and LLM agree: Transport-related keywords detected",
      "metadata": {
        "invoice_text": "Transportkosten per LKW nach Zürich"
      }
    },
    {
      "suggestions": [
        {
          "account": "2004 – Verbindlichkeiten übr. Betriebsaufwand",
          "confidence": 0.95,
          "explanation": "Primary account for category 'Surcharge'"
        },
        {
          "account": "4980 – Surcharges & Fees",
          "confidence": 0.522,
          "explanation": "Alternative account for category 'Surcharge'"
        },
        {
          "account": "4900 – Transport & Freight Costs",
          "confidence": 0.38,
          "explanation": "Alternative account for category 'Surcharge'"
        }
      ],
      "semantic_category": "Surcharge",
      "classification_confidence": 0.95,
      "classification_method": "rule",
      "classification_reasoning": "Rule-based classification: Surcharge keyword pattern matched",
      "metadata": {
        "invoice_text": "Energiezuschlag Januar 2026"
      }
    }
  ]
}
```

---

## Feedback Request Example

### REQUEST
```json
POST /api/v1/feedback
Content-Type: application/json
X-API-Key: dev-key-001

{
  "invoice_text": "Energiezuschlag Januar 2026",
  "suggested_account": "1220 – Materialvorräte",
  "actual_account": "2004 – Verbindlichkeiten übr. Betriebsaufwand",
  "user_id": "vincent_company",
  "comments": "Energy surcharges always go to operational liabilities"
}
```

### RESPONSE
```json
{
  "status": "success",
  "message": "Feedback recorded successfully",
  "feedback_id": "fb_20260119_001"
}
```

---

## Complete Schema Reference

### Request Schema
```typescript
{
  line_item: {
    invoice_text: string (required),
    supplier?: string,
    quantity?: number,
    unit_of_measure?: string,
    unit_price?: number,
    line_amount?: number,
    product_group?: string,
    po_reference?: string
  },
  top_k: number (1-5, default: 3)
}
```

### Response Schema
```typescript
{
  suggestions: [
    {
      account: string,
      confidence: number (0-1),
      explanation: string
    }
  ],
  semantic_category: string,
  classification_confidence: number (0-1),
  classification_method: "rule" | "llm" | "hybrid" | "vendor_1to1",
  classification_reasoning: string,
  metadata: {
    invoice_text: string,
    supplier?: string,
    ...other fields from request
  }
}
```
