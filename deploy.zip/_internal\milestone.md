| Milestone | Scope | Deliverables | Amount |
|----------|-------|--------------|--------|
| **1. Core AI account-coding engine** | Build the core classification logic using LLM + rule-assisted approach | - Input schema definition (invoice line JSON)<br>- Prompt + rule logic for GL prediction<br>- Deterministic JSON output<br>- Confidence score + explanation<br>- Local test harness | $100 |
| **2. API layer + feedback handling** | Production-ready API wrapper around the core logic | - REST endpoints (`/suggest`, `/feedback`)<br>- API key–based access<br>- Request/response validation<br>- Feedback storage hooks<br>- Basic error handling<br>- Ready for Azure App Service | $90 |
| **3. Documentation & handover** | Make it usable + extendable | - API documentation<br>- Example payloads<br>- Setup instructions<br>- Deployment notes<br>- Limitations & next-step roadmap | $50 |
