Vincent Ochs
Machine Learning - AI-Based Account Coding Service
Friday, Dec 26, 2025
Apoorv Pandey
4:35 PM
Hi Vincent
This is a strong idea, and the V1 can be built very efficiently without sacrificing correctness or future scalability.The reason I’m proposing a lower V1 budget ($240) is because you already have OCR, extraction, and ERP integration in place and the first version is zero-shot / rule-assisted, so no historical model training or data pipelines yet. So I think we can use LLM + deterministic rules instead of custom ML models (much faster and cheaper for V1). Also, Azure OpenAI + FastAPI removes the need for heavy infra or experimentation cycles.
So my proposed milestones (lean by design) I have mentioned in milestone section.
This gives you a production-usable, licenseable engine that can immediately collect feedback for a smarter V2 — without paying upfront for training, dashboards, or over-engineering.
I can start immediately and keep iterations tight.
And...do you want confidence scores purely model-based for V1, or rule-weighted + model-assisted?

View details
Vincent Ochs
4:35 PM
Hello!



Did you understand what I need?
Also did you build something like this before?



So to have a solution which is built on AzureML and which can be requested via API calls.

maybe let me record a video to explain

Vincent Ochs
5:05 PM
video1600888536.mp4 
video1600888536.mp4
7 MB
Apoorv Pandey
5:27 PM
Hi, yes I got the idea of your project and I have built closely related systems. I worked for an IOT based startup, they wanted a robust system for electricity bill parsing using ocr and llm, this is project is on my profile as well. I cannot share repository due to confidentiality but I built the backend service that used llm for semantic understanding and reasoning, structured/semi structured input and deterministic output json format with constraints, instruction based prompting ,rule + llm logic, exposing functionality via api , tracing , logging , error handling, evolves through feedback and updates

So in that system the llm would decide how to interpret and classify extracted contents

Which is very similar to your case... That how the service will decide a GL acc, for a given line item nd other parameters. So architecture is pretty much same classification then mapping then confidence and evaluation then explanation and api response

At this very moment I'm traveling and will be available from 27 dec , I'll just go through your video to confirm things once again and update u as soon as I can .

Saturday, Dec 27, 2025
Apoorv Pandey
9:17 AM
You removed this message

Apoorv Pandey
10:20 AM
image.png 
image.png
Apoorv Pandey
12:44 PM
I have changed the terms in this proposal.

View details
Apoorv Pandey
12:58 PM
I’ve gone through your video and the flow you described, and it matches well with the diagram I shared earlier. The idea would be an API-based service on Azure that receives structured invoice rows (JSON/CSV), applies rule-based logic first, and then uses an LLM via Azure OpenAI when needed to map each line to the correct GL account, with a confidence score and short explanation. Feedback can be stored and reused later to improve suggestions, without needing model training in the first version. This can run cleanly on Azure App Service or Container Apps, calling Azure OpenAI, and later be extended either as a shared (multi-tenant) service with API keys and usage limits, or deployed per customer if required. From a product point of view, this supports both per-tenant or per-API-call pricing. I’d structure it in phases: - first the core classification + mapping logic, then the API and feedback handling, and finally documentation and guidance for hosting and scaling ... keeping the first version simple, controllable, and easy to evolve.

Vincent Ochs
9:46 PM
yes exactly !

Apoorv Pandey
9:50 PM
Glad we aligned. If you're okay, then we can discuss the scope and deliverables in more detail. Work for u?

Apoorv Pandey
10:01 PM
plan of all phases.pdf 
plan of all phases.pdf
58 kB
Just sketched the things out... let me know what you think, and we can adjust it however works best for you.

Vincent Ochs
11:42 PM
For the api charging customer, it can be done through api key, like any regular paid service. For hosting, I would recommend hosting it on the cloud. what do you think?

let me check

Apoorv Pandey
Dec 27, 2025 | 10:04 PM
Just sketched the things out... let me know what you think, and we can adjust it however works best for you.

Apoorv Pandey
11:51 PM
Yeah, the API key based access is doable + hosting it on the cloud makes the most sense for this use case.
For first version, simpley run the service on Azure, expose API endpoints, and secure them with API keys so each tenant can be say, rate limited and billed later if required. That actually fits well with per-call or per-tenant pricing models and is easy to extend.

Im sure we just need light and clean backend that works reliably and can evolve using feedbacks. For now, I think.

Later when users grow, things like usage tracking, quotas, or tenant isolation can be added on top without changing much of the core logic.

Sunday, Dec 28, 2025
Vincent Ochs
3:34 AM
what do you think about the pricing? what would be the best solution and what are the typical prices to charge customers?

Apoorv Pandey
5:51 PM
I need for more info to answer that, because that will help me size down the open ai usage, app service size and pricing tiers.

Vincent Ochs
5:55 PM
which info do you need?



and what info do you need to start?

Apoorv Pandey
5:55 PM
Can u tell me, roughly how many invoice line items per day or month do you expect per customer?
How many tenants do you expect initially?
Is this meant for like internal use only? or a commercial SaaS with many external customers?
Is accuracy more important than cost, or do you prefer a cheaper/faster model for most cases?
Should we prioritize deterministic + rule-first behavior?
Should this run in your Azure tenant? or as a shared service you operate?
Any data residency constraints (EU / Swiss only, etc.)? because that will affect the pricing too.

Apoorv Pandey
6:14 PM
Cost of api backend service gonna be free when we first test things, you know, like proof of concept. I am calculating on azure pricing calculator. This is of backend for now, has its limitations but will work as far as we are concerned about testing first.

image.png 
image.png
Apoorv Pandey
6:27 PM
AI model usage cost only, based on assumptions that it will be 10,000 invoice lines/month, 300 input tokens per line, 100 output tokens per line

image.png 
image.png
Apoorv Pandey
6:52 PM
entire cost for proof of concept

image.png 
image.png
I’ve kept the setup intentionally minimal and cost-efficient.

We are using Azure App Service (Free) + Azure OpenAI + basic Blob Storage, because logging and monitoring services are also covered in the app service plan and for early validation phase, we don’t need heavy monitoring or large resource allocations yet.

Apoorv Pandey
7:01 PM
If you can guide me with some approx figures here, based on what your business goals and expectations are, I can give the production costs for you then I can help you better understand the pricing of your service to your customers.

Vincent Ochs
Dec 28, 2025 | 5:55 PM
which info do you need?



and what info do you need to start?

Show more
Apoorv Pandey
Dec 28, 2025 | 5:55 PM
Can u tell me, roughly how many invoice line items per day or month do you expect per customer?
How many tenants do you expect initially?
Is this meant for like internal use only? or a commercial SaaS with many external customers?
Is accuracy more important than cost, or do you prefer a cheaper/faster model for most cases?
Should we prioritize deterministic + rule-first behavior?
Should this run in your Azure tenant? or as a shared service you operate?
Any data residency constraints (EU / Swiss only, etc.)? because that will affect the pricing too.

Show more
Monday, Dec 29, 2025
Apoorv Pandey
2:23 AM
i will get back to you in a few hours

Vincent Ochs
2:24 AM
let me respond tomorrow

thank you

Vincent Ochs
2:15 PM
do you have these files so that you could send those to me?

Apoorv Pandey
Dec 28, 2025 | 6:27 PM
AI model usage cost only, based on assumptions that it will be 10,000 invoice lines/month, 300 input tokens per line, 100 output tokens per line

Show more
Can u tell me, roughly how many invoice line items per day or month do you expect per customer?
-> I guess like 20 per day?



How many tenants do you expect initially?
-> only 1 for now , later more of course



Is this meant for like internal use only? or a commercial SaaS with many external customers?
-> Commercial SaaS



Is accuracy more important than cost, or do you prefer a cheaper/faster model for most cases?
-> Accuracy is more important for now - but it shouldnt get too expensive of course



Should we prioritize deterministic + rule-first behavior?
-> i think it should be LLM ? enhanced / supported by rule-based



Should this run in your Azure tenant? or as a shared service you operate?
-> What would you suggest?



Any data residency constraints (EU / Swiss only, etc.)? because that will affect the pricing too
-> Im not sure about this one

Apoorv Pandey
2:26 PM
Yeah sure

Vincent Ochs
Dec 29, 2025 | 2:15 PM
do you have these files so that you could send those to me?

Just wait few minutes, I'll connect w u

Vincent Ochs
2:34 PM
ok

Apoorv Pandey
2:47 PM
3 files 
POC.xlsx
53 kB
aiservice_gpt-3.5-poc.xlsx
52 kB
appservice_cost_poc.xlsx
52 kB
Now in ai service it was calculated for gpt 3.5 turbo model, but, I found a better model with cheaper pricing, and also the option to cache standard inputs

Do you have any competitors in the market? Like in this niche?

Apoorv Pandey
2:59 PM
let's run this as shared hosted azure service, locked with api keys per customer, and I took west europe by deafualt, cuz you are switzerland based, and I think your clients are going to be more EU based. And europe servers are one of the most stable and widely used. Also there maybe local regulations on where to store the data, so you might have to store them on EU servers, or Switzerland only. And I will just calculate everything again based on the info you just provided, maybe check some competitors of yours and how they are pricing and then come up with what will be the estimated costs you will incur, and what should be your revenue model/ how much should you charge. The files were downloaded from the azure pricing calculator. Will get back to you with more updates.

Vincent Ochs
Dec 29, 2025 | 2:17 PM
Can u tell me, roughly how many invoice line items per day or month do you expect per customer?
-> I guess like 20 per day?



How many tenants do you expect initially?
-> only 1 for now , later more of course



Is this meant for like internal use only? or a commercial SaaS with many external customers?
-> Commercial SaaS



Is accuracy more important than cost, or do you prefer a cheaper/faster model for most cases?
-> Accuracy is more important for now - but it shouldnt get too expensive of course



Should we prioritize deterministic + rule-first behavior?
-> i think it should be LLM ? enhanced / supported by rule-based



Should this run in your Azure tenant? or as a shared service you operate?
-> What would you suggest?



Any data residency constraints (EU / Swiss only, etc.)? because that will affect the pricing too
-> Im not sure about this one

Show more
Tuesday, Dec 30, 2025
Vincent Ochs
3:24 PM
nothing i am aware off - maybe you know?

Apoorv Pandey
Dec 29, 2025 | 2:51 PM
Do you have any competitors in the market? Like in this niche?

these are the costs for the POC - how expensive would it be for the customer then for running the invoices ?

and whats next?

Apoorv Pandey
3:29 PM
Early-Production-estimates.xlsx 
Early-Production-estimates.xlsx
53 kB
Vincent Ochs
3:31 PM
how many invoices are being processed with that?

Apoorv Pandey
3:31 PM
20 per day i.e 600 per month

Vincent Ochs
Dec 30, 2025 | 3:31 PM
how many invoices are being processed with that?

Vincent Ochs
3:31 PM
600 invocies per month would cost 13 USD ?

17*

Apoorv Pandey
3:33 PM
No, that is inclusive of all the services

Only ai service for 600 invoices per month will cost you $2.80

monthly

there are other costs, such as azure app service. and blob storage, in which we are using 1GB only, enough for early production

you can go through each service and its cost.

cost per invoice line is approx 0.03 cents

Vincent Ochs
3:40 PM
ok

how much can we then / should then "charge" the customer?



1. license based?
2. per invoice?
3. what about set up cost?

what do you suggest?

Apoorv Pandey
3:43 PM
see your reeal cost is approx ~$0.0003 per invoice line

so for per invoice i think it will be much easier to sell

even if you out price per invoice for the most basic plan

say $0.01 per line

you will be at a 30 times margin from what it is actually costing u

but

Vincent Ochs
3:45 PM
i thought 0.03 ? now you say 0.0003 ?

Apoorv Pandey
Dec 30, 2025 | 3:43 PM
see your reeal cost is approx ~$0.0003 per invoice line

Apoorv Pandey
3:45 PM
0.03 cents and 0.0003 dollars

Vincent Ochs
3:45 PM
oh now you are talking about Dolla

ok

Apoorv Pandey
3:45 PM
yes

i know we need a pricing, that doesn't look to heavy for your customers

can cover our costs in production and setup, and make profit too. I just need to study this niche a bit more

to see what your competitors are charging

Vincent Ochs
3:47 PM
ok

Apoorv Pandey
3:48 PM
and another thing i want to make clear

Vincent Ochs
3:48 PM
?

Apoorv Pandey
3:49 PM
this suggestion came only from considering the ai service cost. Right? but we are being charged

Apoorv Pandey
Dec 30, 2025 | 3:44 PM
say $0.01 per line

for storage and app service too

based on that

Vincent Ochs
3:49 PM
i dont understand what you mean

Apoorv Pandey
3:51 PM
the estimate of dollar 0.01 per line was just a part of what we are charging the user for our ai service, this needs to add more prices too, to cover for our expense on app service and storage service which are giving them

you can do this

Flat monthly price for usd 50 giving 1000 lines per month

Vincent Ochs
3:52 PM
ok

maybe we can see competitors?

Apoorv Pandey
3:52 PM
can you do a meeting someday?

yes, i think this project of yours is for accounting businesses?

Vincent Ochs
Dec 30, 2025 | 3:52 PM
maybe we can see competitors?

Vincent Ochs
3:53 PM
yes

Apoorv Pandey
3:54 PM
Okay, if you have any names please drop them , meanwhile I will do my own research and update you.

Vincent Ochs
3:54 PM
i dont have any names yet- will have to check too

Apoorv Pandey
3:58 PM
Its ok. When you have found something you can tell me, I will update you what i can find.

Vincent Ochs
3:58 PM
ok

Apoorv Pandey
6:10 PM
ok so I did some homework here

Our costs:
17 usd/ month
per invoice line : $17 / 600 ≈ $0.028 per invoice.

now, for pricing, your rivals here in the field of amount payable/receivable automation are: bill.com, Melio, Tipalti, Stampli, Bill Trust, Invoiced.

BILL | Financial Operations Platform for Businesses & Firms
The AP, AR, and spend & expense solution that lets you create and pay bills, manage expenses, control budgets, and get the credit your business/firm needs to grow.
They do NOT price per invoice cleanly, but effective cost works out to:

image.png 
image.png
rough estimates

Apoorv Pandey
6:25 PM
they sell payments, approvals, UI-heavy workflows, vendor portals, accounting sync management, compliance reporting, payment rails

we are selling one API endpoint that predicts GL accounts accurately. right?

This makes me think that we are a plug-in intelligence layer they could even use internally. So, in a way they can be our potential clients than rivals.

Apoorv Pandey
7:11 PM
https://docs.google.com/document/d/1ZcePyU-JC7quAQjktCp4iUuV0Jnf1y_2nKRSh7ZZ7a4/edit?usp=sharing

Apoorv Pandey
7:24 PM
I’ve shared everything needed around pricing, market benchmarks, and structure. At this point, the remaining decisions are mostly about scope and how you want to move forward. To go further, we should lock this into a contract so I can start building the actual system. You can just tell me which direction you want to go, and I’ll take it from there. Let me know...

Vincent Ochs
7:47 PM
yes

Apoorv Pandey
Dec 30, 2025 | 6:26 PM
we are selling one API endpoint that predicts GL accounts accurately. right?

how do they sell that then?

Apoorv Pandey
Dec 30, 2025 | 6:25 PM
they sell payments, approvals, UI-heavy workflows, vendor portals, accounting sync management, compliance reporting, payment rails

Show more
thank you!



yet let me review and then we can discuss?

Apoorv Pandey
Dec 30, 2025 | 7:24 PM
I’ve shared everything needed around pricing, market benchmarks, and structure. At this point, the remaining decisions are mostly about scope and how you want to move forward. To go further, we should lock this into a contract so I can start building the actual system. You can just tell me which direction you want to go, and I’ll take it from there. Let me know...

Show more
Apoorv Pandey
8:08 PM
Yeah exactly they don’t really sell “just the model” like we do. Bill, Melio, Stampli etc. sell full workflow platforms: payments, approvals, vendor portals, UI, syncs, compliance, reporting, etc. The AI is just one internal component inside that big product.

Vincent Ochs
Dec 30, 2025 | 7:47 PM
how do they sell that then?

What we’re building is different and actually more niche specific

We’re selling one focused capability that is accurate GL prediction as an API.
This is an intelligence layer that those platforms could even plug into.

So instead of charging like a full AP system, we price it like an API / ML service like per usage (per invoice line), or via a small monthly plan with usage included.

That’s why pricing at a few cents per line still makes sense, even though their end product costs $50–$500/month it is because they bundle a lot more UI + workflow + payments around it.

In short:
they sell a platform
we sell a core intelligence component

Okk... Review it whenever you’re ready, and then we can align on next steps.

Vincent Ochs
Dec 30, 2025 | 7:48 PM
thank you!



yet let me review and then we can discuss?

Show more
Vincent Ochs
8:56 PM
but one functionality of their platform is also including the service we are planning to offer?

Apoorv Pandey
8:59 PM
Yes, that is a part of their service.

Wednesday, Dec 31, 2025
Vincent Ochs
3:32 PM
ok so what would be the next steps?

Apoorv Pandey
10:02 PM
ok, so I think we’ve officially analyzed this enough

The numbers make sense, the market makes sense, i mean on rough estimates

Now the only thing left is actually building it.

The smart move

in my opinion is

small MVP, real usage, real feedback. That’ll answer pricing plus positioning way better than our spreadsheets.

We’re not trying to be Bill or Melio

We are building a focused brain people like them could use. That’s the edge, according to what I think..
If you’re good with that, we can lock scope and turn this into a contract so I can start implementing. Or we can hop on a quick call and align...whatever’s easier for u

as a sidenote tho

I checked your LinkedIn profile before our discussions, and it was really cool. You got lots of experience

so, I am pretty confident... you can make this work for sure.

That's why I will be glad to turn this into something real whenever you say.

Friday, Jan 02
Vincent Ochs
4:19 PM
okay - i like that

lets start?

Apoorv Pandey
4:24 PM
Sure we should 👍🏻. Let's do this

Apoorv Pandey
6:39 PM
https://docs.google.com/document/d/1rmtAUFScYyjBw_LmHYsqHbl1dCIyeR9Z3xEQwt8LqwI/edit?usp=sharing

Apoorv Pandey
7:06 PM
I’ve cleaned up and specified the milestones better to make scope and deliverables more defined. You can review everything then let me know if you want anything changed or updated from what I proposed. Also let me know if you have any deadlines.

Vincent Ochs
7:07 PM
let me check

Apoorv Pandey
7:44 PM
Ok

Saturday, Jan 03
Vincent Ochs
12:24 PM
yes that would be fine with me

Apoorv Pandey
12:43 PM
Ok then let's start

Vincent Ochs sent an offer

12:45 PM
We are looking to build a backend AI service that generates general ledger (GL) account coding suggestions for invoice line items. So we need someone who is familiar with developing an AI based product. Any recommendation of the freelancer is welcomed if our idea is not good enough etc.



The document extraction, OCR, and ERP integration already exist.
Our service will receive structured exports of invoice line items and return account coding suggestions via API.



Input (via API):
-Invoice line item text (free text)
-Supplier name / ID
-Quantity
-Unit of measure
-Unit price / line amount
-Optional: product group, PO reference
-Customer-specific chart of accounts (GL accounts)



Output (via API):
-Top 1–3 suggested GL accounts
-Confidence score per suggestion
-Short explanation (why this account was suggested)
-Optional: high-level category (e.g. material, transport, surcharge, service)
-The ERP system will consume the response and write the final booking after user confirmation.



Core Logic
-Semantic classification of invoice line items
(e.g. material, consumables, tools, transport, surcharge, service)
-Mapping of category → chart of accounts
-LLM-based reasoning for cases where rules are insufficient
-Deterministic JSON output (no free-form text responses)
-Initially, the system works without historical training data (zero-shot / rule-assisted LLM).
-User confirmations and corrections are logged for future model training.



Technical Expectations
-Backend service (Python preferred, e.g. FastAPI)
-REST API (/suggest, /feedback)
-Azure-based deployment (Azure Container Apps or App Service)
-Azure OpenAI used for semantic understanding (LLM)
-Structured logging, versioning, and basic monitoring



Outcome
A reusable, licenseable AI Account Coding Engine that can be embedded into existing ERP or DMS workflows and improved over time via feedback.



Further milestones can be set up if needed.

Est. Budget: $240.00

Milestone 1: Core AI account-coding logic

Project funds: $100.00

View offer
Apoorv Pandey accepted an offer

12:46 PM
Happy to be part of your venture.

View contract
Apoorv Pandey
12:52 PM
use the github profile on my profile page to add me to your project

Vincent Ochs
1:43 PM
there is none existing yet- can you create one as private and add me as co-owner?

vincentochs

Apoorv Pandey
2:12 PM
Ok, I have sent an invitation to you.

Vincent Ochs
9:22 PM
Thank You

can you start ?

what do you need from
Me ?

Apoorv Pandey
9:25 PM
yes, just a moment


Apoorv Pandey
9:58 PM
To start, please send the following-
1. Your GL account list and
2. A few sample invoice lines
3. Any rules or preferences for mapping if you have them

Apoorv Pandey
10:44 PM
Have u created the Azure account nd set up the services/resource groups for this project? If yes, then add me as contributor/ co-owner so I can deploy and configure the service for PoC and testing.

Sunday, Jan 04
Vincent Ochs
3:55 AM
hello - you can log into my azure account if you want and you can check there and set up the project

i can send you an example with invoice lines - but the real GL accounts we will receive in a few days only

invoice_text_with_accounts.xlsx 
invoice_text_with_accounts.xlsx
7 kB

Apoorv Pandey
2:32 PM
Yea that would help too. Please send the credentials so I can login. I am working out logics using these samples for now.

Apoorv Pandey
10:05 PM
https://github.com/apoorvpandey048/ai-account-coding-engine/invitations

Apoorv Pandey
10:20 PM
Hello

Vincent Ochs
10:42 PM
ok sure

Apoorv Pandey
Jan 4, 2026 | 2:32 PM
Yea that would help too. Please send the credentials so I can login. I am working out logics using these samples for now.

Show more
accepted

Apoorv Pandey
Jan 4, 2026 | 10:05 PM
https://github.com/apoorvpandey048/ai-account-coding-engine/invitations

please treat confidential



vincent.ochs@agalith.com



PW: Kevamma160196!

Apoorv Pandey
10:45 PM
Absolutely. I will set everything up and inform u.

please send the code u got on ur authenticator app

Vincent Ochs
10:48 PM
ok

785191

please inform me or ask me before you buy something etc

Apoorv Pandey
10:50 PM
Yes ofc, I will just add things and share screeshots with you, you can review and finalize when to make purchase.

Monday, Jan 05
Vincent Ochs
12:41 AM
thanks

Apoorv Pandey
1:07 AM
Hey, I will continue setting up in the morning. Anywhere payments have to be made I will stop at that point and let you know. Also, what timezone are u in exactly? like what time is it there right now, it shows 8:36 pm on upwork but just curious? its 1 am night here.

Vincent Ochs
1:52 AM
What do you mean ? „Anywhere payments have to be made“?



Is there a free trial for Testing?

yes it was 8:36



So you are 4 1/2 hours ahead of me

Apoorv Pandey
3:13 PM
No, just saying in general sense.

Vincent Ochs
Jan 5, 2026 | 1:52 AM
What do you mean ? „Anywhere payments have to be made“?



Is there a free trial for Testing?

Show more
Vincent Ochs
3:18 PM
ok

Vincent Ochs
7:45 PM
just let me know when you can continue

Apoorv Pandey
7:46 PM
I am working

services have been deployed

I am running smoke tests and confirming results

Vincent Ochs
7:47 PM
can you show me where they are?

Apoorv Pandey
7:47 PM
image.png 
image.png
I have to configure the model , tokens, etc

next.

and every change will be made on the dev branch for now. we will merge in main later ofc.

Vincent Ochs
8:02 PM
where cna i see that? on my azure account?

Apoorv Pandey
Jan 5, 2026 | 7:48 PM
I have to configure the model , tokens, etc

Apoorv Pandey
8:04 PM
yea, I have configured model tokens and everything

see the resource group ai-account-coding in your azure account

all services are there

image.png 
image.png
Vincent Ochs
8:11 PM
great

Apoorv Pandey
8:11 PM
This just shows your infrastructure is ready. I am going to integrate the api endpoints with the code and test again.

Vincent Ochs
8:11 PM
the code is where? on your github repo for now?

Apoorv Pandey
8:12 PM
Yes , u accepted the invite ig?

we will work on dev branch for now, merge later in main when we are confident about our product. ok?

Vincent Ochs
8:15 PM
yes

ok

Apoorv Pandey
8:16 PM
Will update you again in about an hour. Btw do you have a deadline for entire project?

Vincent Ochs
8:20 PM
just asap

no specific deadline

Apoorv Pandey
8:22 PM
Oh, Okay I get it.

Apoorv Pandey
10:44 PM
health checks have passed but for its stopped syncing with latest repo changes. I am working to fix this issue.

ai is working locally

image.png 
image.png
Vincent Ochs
10:47 PM
sure

Tuesday, Jan 06
Apoorv Pandey
12:03 AM
image.png 
image.png
Vincent Ochs
12:06 AM
can you test it and provide me an accuarcy ?

Apoorv Pandey
12:06 AM
yea, i did on this sample, confidence scores are given too

Vincent Ochs
12:07 AM
whats accuarcy?

Apoorv Pandey
12:08 AM
ai models dont really use accuracy for such output generation, because we never really had any training/testing data splits

they give a score of how confident they are about their output.

this is just showing that api is live and working, and the ai is intelligently recommending top 3 gl accounts with explanation

this is using /suggest endpoint, I will later check the /feedback endpoint too

Vincent Ochs
12:11 AM
but if you test it with your data- you know the ground truth ?



So you can tell me how often it suggested correctly and how many times it didnt?

Apoorv Pandey
12:11 AM
This file, I can use as ground truth? You were going to send more

Vincent Ochs
Jan 4, 2026 | 3:55 AM
i can send you an example with invoice lines - but the real GL accounts we will receive in a few days only

Vincent Ochs
12:11 AM
yes next week i have the meeting, we only have that test file for now

Apoorv Pandey
12:11 AM
So for now i can use that test file

right

Treat it as ground truth

Vincent Ochs
12:12 AM
and why does it say confidence = 0.95 and then later it says best confidence = 0.15?

Apoorv Pandey
12:12 AM
that is the threshold

if less than 0.15 it will fallback to rules

I forgot to update the code. Good catch.

when it was first using rule based approach the confidence was recorded 0.15, the threshold for fallback on Ai is set to be 0.5. so the best score is actually of rule based approach.

it is just that in debug part i did not update it to show the final best confidence, it only printed initial score only. updated that. pushed, redeploying and sharing new result. it takes a few minute tho everytime. CI/CD needs to be set up too.

image.png 
image.png
Vincent Ochs
12:26 AM
ok, sounds good

any metrics which you can generate based on the data we have so far?

want to see how "well" it performs

Apoorv Pandey
12:28 AM
No I haven't added that. I am planning to use all those 30 entries of data. And some functions which will help us measure the performance. I will be sure to update you with that.

Vincent Ochs
12:55 AM
sure

Apoorv Pandey
1:20 AM
I have done some testing and the ai is acting creative , like its creating these number codes that were not really part of the dataset. I will fix that. I will update to you in the morning alright? I will try to have this thing give perfect responses based on the data we have yet, along with the metrics.

Vincent Ochs
1:25 AM
ok

thank you

thats why we need metrics- otherwise we cannot trust the system

Apoorv Pandey
12:10 PM
I will need ur help signing back to azure. Let me know when you are online.

Apoorv Pandey
12:31 PM
hello

Vincent Ochs
12:31 PM
now

Apoorv Pandey
12:31 PM
yes

I am signing in again

please send the verification code

Vincent Ochs
12:31 PM
now?

Apoorv Pandey
12:32 PM
yes

Vincent Ochs
12:32 PM
ok

664369

Apoorv Pandey
12:32 PM
Thanks

Vincent Ochs
12:35 PM
connected?

Apoorv Pandey
12:36 PM
yes

Apoorv Pandey
8:13 PM
image.png 
image.png
image.png 
image.png
image.png 
image.png
6/10 correct. i implemented feedback for 2nd sample.

Vincent Ochs
8:16 PM
but we did not train that yet on our data - did we?
would that increase the performance if we fine tune the model based on our data?

Apoorv Pandey
8:17 PM
I used fuzzy string matching before ai

deterministic rule sets were used and I got all 10/10 correct. but since datast was so small I dont think we should expect same for new entries

as for ai, few shot sampling

as i did above in next run will definitely make it 10/10

I am thinking how do we generalise it better, because in future we will have more invoice texts and they will be of variety

Vincent Ochs
8:19 PM
so before we had 6/10 - aber after trainaing we had 10/10 ?

yes

Apoorv Pandey
Jan 6, 2026 | 8:19 PM
I am thinking how do we generalise it better, because in future we will have more invoice texts and they will be of variety

Show more
Apoorv Pandey
8:20 PM
7/10, i only gave it the feedback that second sample is related to transport, not surcharge and fees

Vincent Ochs
Jan 6, 2026 | 8:19 PM
so before we had 6/10 - aber after trainaing we had 10/10 ?

so

I am thinking I will store these examples, the 39 samples

part of a cached input

Just a moment, let me re try with this

Meanwhile u can see the suggestion it gives are more natural context based. It is not trained. This is more like how ai will perform for say literally unseen invoices. All it has used is a prompt. I will try few shot prompting and tell how it performs.

Vincent Ochs
8:25 PM
ok

Apoorv Pandey
9:01 PM
I tried

7/10

after few shot prompting of all the examples.

when we will actually go for production how big of a data we will have as our ground truth/training data?

and tbh, the explanation of the ai is sensible in its own ways, in the cases where it was off from our set ground truths.

Apoorv Pandey
9:16 PM
I need more data for fine tuning, 39 is way too less.

Thinking of training a custom gpt model. will save lots of tokens per request too.

Apoorv Pandey
10:38 PM
I implemented RAG, reduced token cost by half but results 6/10. I am currently working fine tune a model and it will take some time.

Apoorv Pandey
10:45 PM
from azure documentation

image.png 
image.png
I think it is ok for us to have 60% accuracy when only implemented with not custom trained ai model.

We can track and modify this better when we have more data at our disposal. To make well generalized and robust solutions.

I mean after all we tested only on 10 samples.

Apoorv Pandey requested payment for the milestone

3:19 AM
Milestone 1 complete. Core AI account-coding engine integrated with Azure OpenAI. Deliverables packaged at milestone1.zip — code, tests (29/29), evaluation results, charts, examples, and full report. Key metrics: Hybrid Top-1 = 90% (post-feedback 100%), human review ≈20%. all metrics based on sample set of size 10.

Milestone 1: "Core AI account-coding logic"

Amount: $100.00

View details
milestone1.zip 
milestone1.zip
243 kB
Okay so. It correctly picks the right account first 90% of the time, and the correct account is in the top 3 suggestions 100% of the time. With a quick user correction step that is feedback, the test set reached 100% accuracy. Using a confidence cutoff of 0.7, about 80% of invoices are auto-handled and 20% need review. You can go through the zip files to review everything.

Apoorv Pandey requested payment for the milestone

3:50 AM
please ignore the first one, this is my deliverable for first milestone.

Milestone 1: "Core AI account-coding logic"

Amount: $100.00

View details
milestone1.zip 
milestone1.zip
241 kB
Apoorv Pandey
11:38 AM
Half of milestone 2 is also done but I need your clearance here.

Vincent Ochs
1:19 PM
much bigger i think, but i cant tell now

Apoorv Pandey
Jan 6, 2026 | 9:03 PM
when we will actually go for production how big of a data we will have as our ground truth/training data?

how much?

Apoorv Pandey
Jan 6, 2026 | 9:16 PM
I need more data for fine tuning, 39 is way too less.

60% is really bad tbh..

Apoorv Pandey
Jan 6, 2026 | 10:46 PM
I think it is ok for us to have 60% accuracy when only implemented with not custom trained ai model.

Apoorv Pandey
1:23 PM
They use very large datasets to cover as much patterns as possible. Like gpt itself will suggest 100+ . But I think we should get even more . So as much as possible

Vincent Ochs
Jan 7, 2026 | 1:19 PM
much bigger i think, but i cant tell now

Vincent Ochs
Jan 7, 2026 | 1:20 PM
how much?

The thing is we also need to be sure that our ground truths themselves are 100% correct

Vincent Ochs
1:25 PM
i can get more than 100 i guess

Apoorv Pandey
1:26 PM
Then I'll prepare it for custom fine tuned model.

Vincent Ochs
Jan 7, 2026 | 1:25 PM
i can get more than 100 i guess

Vincent Ochs
1:27 PM
how good is the performance currently?



I am confused - first you say 9/10 , then 6/10 , then 100% ....

Apoorv Pandey
1:27 PM
Yeah I was coming to that

Vincent Ochs
Jan 7, 2026 | 1:27 PM
how good is the performance currently?



I am confused - first you say 9/10 , then 6/10 , then 100% ....

Show more
So 60% is semantic only approach accuracy for the top 1 suggestion.

When running again for the hybrid pipeline which uses glpredictor we achieve 90% on top 1 accuracy and 100% top 3

With 80% automation rate and 20% flagged for review

Then u remember we had feedback

When applying feedback to this pipeline, that is we added the correct suggestion of the mapping to our storage which our system remembers . So in this run I will give all correct

Because we had already rectified it's previous mistake

In the zip file I sent some images too

The system gives top 3 mapping suggestions with explanation right ? So I wanted to see if it is giving the first suggestion correct or not ( top 1 accuracy) and also if the correct mapping is part of the top 3 suggestions or not ( top 3 accuracy)

U see hybrid pipeline is correct 9/10 times for giving the correct suggestion, and 10/10 times the correct suggestion is part of the top 3 suggestions ( only in one case It wasn't the first suggestion)

Please rectify me anywhere if I'm getting a wrong idea of our project?

Apoorv Pandey
1:47 PM
Yesterday I had also toyed with the model parameters, and RAG by embedding the small set . But the best it achieved was 7/10 . And it actually is not much use when we try them on such a small set. When we have bigger datasets we can more confident about generalising. If there's anything you'd like to know I'm right here👍🏻

Vincent Ochs
3:46 PM
what does that mean?

Apoorv Pandey
Jan 7, 2026 | 1:28 PM
So 60% is semantic only approach accuracy for the top 1 suggestion.

and what does "top 1 and top 3" mean?

Apoorv Pandey
Jan 7, 2026 | 1:29 PM
When running again for the hybrid pipeline which uses glpredictor we achieve 90% on top 1 accuracy and 100% top 3

Show more
Apoorv Pandey
3:47 PM
See our system get's the invoice text, then it will give top 3 suggested accounts the invoice should be mapped to

with reason for each suggestion

let me share the outputs

Apoorv Pandey
4:04 PM
please share the code

i hve to login again

it must have come now

Vincent Ochs
4:08 PM
ready?

Apoorv Pandey
4:09 PM
yes

Vincent Ochs
4:10 PM
ok

400281

Apoorv Pandey
4:11 PM
image.png 
image.png
session timed out i will try again, first i will explain the response

Vincent Ochs
Jan 7, 2026 | 4:11 PM
400281

so in the photo you see the output response our system, ok

so, we get 3 suggested gl acc per invoice text based on the confidence our llm? ok

so i checked 2 things

if the highest confident answer of our system was matching the ground truth or not (top 1 accuracy)

or, if the ground truth was matched by at least one suggestion of the 3, ignoring the confidence.(top 3 accuracy)

like for the invoice text Zollgebuhren import, the system gives 3 suggestions

that it is 85 per cent confident that this invoice should be mapped to 4900 - transport nd freight costs

first suggestion is most confident

then it gives the next 2 suggestions with lesser confidence that it might be mapped to 4980 or 4200

so 90% top 1 accuracy means that ground truth matched highest confident answer of the system

for 9/10 cases

in that 1 case, the 1st suggestion did not match to the ground truth, but 2nd or 3rd suggestion which have less confidence may have

that is why 100% top 3 accuracy

now, we also had feedback mechanism right?

in the next run, what the user does is he gives feedback for that 1 case where 1st suggestion was wrong. he sends a feedback that this acc should be mapped to this. so the next time the system is called, nd system sees that edge case, it will remember the feedback given, nd map it as the user said.

when we will have a larger set, we can improvise it the same way.

there are lots of options in front of us, but we can understand nd evaluate them better we have more data, nd variety. because again, even if we get 100% accuracy using this 49 sample dataset, we cannot be sure it will be 100% accurate always because there are much more invoices than just our sample

u understanding right? small data -> easy to cover nd learn patterns -> variance will be high

9/10 times ground truth matched 1st suggestion

Apoorv Pandey
Jan 7, 2026 | 4:20 PM
for 9/10 cases

10/10 times ground truth was part of the 3 suggestions per invoice

Apoorv Pandey
Jan 7, 2026 | 4:22 PM
that is why 100% top 3 accuracy

.

Apoorv Pandey
8:15 PM
Actually I tested the 3 components of our system separately nd was telling you the scores for each, ... That's why it looks a bit complicated.

I am thinking to try training the model with our current dataset. Can u send me the code if I login right now?

Apoorv Pandey
9:08 PM
3 files 
hybrid_report.csv
2 kB
eval_results.json
2 kB
hybrid_report.json
7 kB
You just go through these; everything will be clear. Mainly, just read the csv file.

Thursday, Jan 08
Apoorv Pandey
12:55 AM
Hi

Vincent Ochs
12:58 AM
let me review

Apoorv Pandey
12:59 AM
Sure. I was asking if u give me a time for tomorrow, I will login and try custom training a suitable llm model

Vincent Ochs
1:23 AM
ok

sure

Vincent Ochs
3:22 PM
did you try custom training suitable llm model?

Apoorv Pandey
3:23 PM
No. I have to login to azure again .

Just a moment pls

can u send the code

u must have got received it now

Vincent Ochs
3:25 PM
yes

Apoorv Pandey
3:26 PM
pls send

Vincent Ochs
3:26 PM
ok

ready?

Apoorv Pandey
3:26 PM
yes

Vincent Ochs
3:26 PM
253027

Apoorv Pandey
3:27 PM
Thanks. I will test nd tell u the results

Vincent Ochs
3:27 PM
ok thank you


Vincent Ochs
3:27 PM
ok thank you

Apoorv Pandey
9:27 PM
Hi

I had to stop before acting on training and deploying a custom model

because there will be additional charges

Estimated training cost for our dataset:
Developer: 1,000/1,000,000 x $2.50 ≈ $0.0025
Global: 1,000/1,000,000 x $5.00 ≈ $0.005
regional doesn't exist for west europe.

Apoorv Pandey
9:44 PM
then there is hosting charge, ≈ $1.70 / hour, if we left it running for a day it will be $40.80/day. So, I would want to avoid hosting for now and just train and evaluate by creating an on demand deployment. This way we pay only training , per-inference token costs, and costs of using a grader... these are going to cost roughly less than 2 usd in total. there are advanced additions to training pipeline such as reinforcement learning and provisioned throughput and they will increase the cost by 50-100 usd depending on how long it takes for them to train and other criterias. I would rather not touch them for we have a small set, and

I still believe our existing pipeline has good accuracy

I would suggest we complete the rest of the milestones so that the project isn't stalled. We can definitely update our pipeline when we have more data.

Bcz yk when we have models involved, we try to find the best fit for our business solution, by focusing on the metrics will serve the best, and minimize the risks right? so it lots of testing, we analyse, make a hypotheses, apply some solution based on theoritical knowledge, if things dont improve we find reasons and we try something else which should work in theory, if it does, we try to improve more

Apoorv Pandey
10:08 PM
If u tell me to train the gpt, I will do it in the minimal costs without those additional tools and hosting. Or I can continue the remaining project and by maybe edit the remaining milestone to cut some costs and create a new one in what remains on agreed budget, related to improvising the system if it is more comfortable. Or by just continuing to add updates , revised submissions. After and during completion of all 3.

whatever you'd like


Friday, Jan 09
Vincent Ochs
1:13 AM
whast the difference between developer and global?

Apoorv Pandey
Jan 8, 2026 | 9:30 PM
Estimated training cost for our dataset:
Developer: 1,000/1,000,000 x $2.50 ≈ $0.0025
Global: 1,000/1,000,000 x $5.00 ≈ $0.005
regional doesn't exist for west europe.

Show more
will our performance get better if we add more data? even without training

Apoorv Pandey
1:18 AM
Dev for sandboxing, experiments and prototyping
Global for production grade deployment, fully available with SLA.

Vincent Ochs
Jan 9, 2026 | 1:13 AM
whast the difference between developer and global?

Yes

Vincent Ochs
Jan 9, 2026 | 1:15 AM
will our performance get better if we add more data? even without training

Either using few shot prompting, RAG with embedding, etc

It will be better

But quality matters too

We need to be sure the ground truths make sense

Just curious

Did u check all the rows of that sample set ? To confirm if they were correct ?

Apoorv Pandey
1:33 AM
image.png 
image.png
I one of my earlier tests, the llm mapped it 4980 – Surcharges & Fees. And the reason it gave was this is import duties, but u can see the ground truth we had set was transport and freighter costs.

So there is this Idea I had that would also increase the accuracy in future

that define the contexts of each type of account. again, that is something that we can continue to improve and research.

Vincent Ochs
1:30 PM
Yes

Apoorv Pandey
Jan 9, 2026 | 1:25 AM
Did u check all the rows of that sample set ? To confirm if they were correct ?

I will get real Data within the Next few days !

How to Set up a „barier“ so that People have to pay for it ?


Apoorv Pandey
2:04 PM
We put our service behind a paid gate, secured by api keys, unauthenticated requests will be rejected.
We can either use Stripe for subscriptions, metered billing per invoice line. Or list on Azure Marketplace for enterprise procurement & billing integration. Assign each paid customer a plan as free/trial / starter / pro and per plan quotas.

Vincent Ochs
Jan 9, 2026 | 1:31 PM
How to Set up a „barier“ so that People have to pay for it ?

We will also set up usage count and will need to enforce the quotas against "abusive" customers

Vincent Ochs
2:43 PM
What do you recommebd ?

Apoorv Pandey
Jan 9, 2026 | 2:04 PM
We put our service behind a paid gate, secured by api keys, unauthenticated requests will be rejected.
We can either use Stripe for subscriptions, metered billing per invoice line. Or list on Azure Marketplace for enterprise procurement & billing integration. Assign each paid customer a plan as free/trial / starter / pro and per plan quotas.

Show more
Apoorv Pandey
3:18 PM
Let's drop stripe. There are better options. Azure used to have a api management service too. So I'll have to check if it's only for testing-tracing api or it has features that support sales of api. I'll get back to u with some research. Meanwhile, what do u feel our next steps should be for now ?

Vincent Ochs
4:18 PM
i can get the data and send it to you - then we have a final evaluation of how well it works - followed by that we can set up the API and the "gating"

Apoorv Pandey
4:20 PM
Ok understood.

Monday, Jan 12
Vincent Ochs
12:14 PM
i have now received the data

9 files 
1_Invoice_fields.json
2 kB
1.1_Invoice_fields.json
1 kB
1.2_Invoice_fields.json
5 kB
2_Invoice_fields.json
718 bytes
2.1_Invoice_fields.json
266 bytes
2.2_Invoice_fields.json
266 bytes
3_Invoice_fields.json
2 kB
3.3_Invoice_fields.json
138 bytes
3.1_Invoice_fields.json
532 bytes
Vincent Ochs
12:41 PM
these are 3 examples

Apoorv Pandey
12:43 PM
Thank you very much.

I will update you with our progress here

Apoorv Pandey
1:38 PM
hey, when you come online again please msg me. Need to sign in

Vincent Ochs
1:46 PM
Now ?

Apoorv Pandey
1:46 PM
yes

im gonna sign, send the code pls

Vincent Ochs
1:46 PM
146708

Connected ?

Apoorv Pandey
1:47 PM
yes thank you

Vincent Ochs
1:47 PM
Great

Apoorv Pandey
1:47 PM
u used german

right

Vincent Ochs
1:47 PM
Yes

Apoorv Pandey
1:47 PM
ok then, I am going to run new checks using this data

Vincent Ochs
1:48 PM
Thank You

perfect

Apoorv Pandey
1:48 PM
I will discuss the results nd anomalies shortly.

Vincent Ochs
4:23 PM
ok

Apoorv Pandey
4:24 PM
i see these are not labelled

they come directly from ur ocr system?

Apoorv Pandey
7:46 PM
https://docs.google.com/document/d/1WGv98I7HP-g0rsaaRVgs8yB2MW0c8WtF5l1cb_rVjYs/edit?usp=sharing

Apoorv Pandey
8:07 PM
Hey these lack the target variable, i mean they're not having the suggested account I could have used as a ground truth . I have however increased the "vocab" of our system regarding certain words for different account categories. Alright, I used all examples from previous set , and tested against 10 from the jsons u sent today. Since they were not labelled, I translated them to english and suggested account mapping to them as ground truth, unseen to the system. Ran the tests, and the results are in the Google docs. Do let me know if you want me to label all jsons for ground truth or you will send me by verifying your own ?

Vincent Ochs
Jan 12, 2026 | 12:41 PM
these are 3 examples

Tuesday, Jan 13
Vincent Ochs
1:31 PM
Hello!



Sorry i was very busy yesterday

are the results good?
what are the results of using the json files?

Apoorv Pandey
Jan 12, 2026 | 8:07 PM
Hey these lack the target variable, i mean they're not having the suggested account I could have used as a ground truth . I have however increased the "vocab" of our system regarding certain words for different account categories. Alright, I used all examples from previous set , and tested against 10 from the jsons u sent today. Since they were not labelled, I translated them to english and suggested account mapping to them as ground truth, unseen to the system. Ran the tests, and the results are in the Google docs. Do let me know if you want me to label all jsons for ground truth or you will send me by verifying your own ?

Show more
So generally in JSON under designation.



Some also have IDs, so we need to check with the customer again whether this can always be mapped 1:1, as travel expenses/lunch allowances always come from one vendor, for example.

We have an overview of the accounts, but they are very detailed.
i have to discuss the NDA again with my customer



Alternatively, I can create another extract that is not critical, if that helps.

Apoorv Pandey
5:17 PM
yea, u can check the doc file link. it covers well and is giving accurate 1st account suggestion.

Vincent Ochs
Jan 13, 2026 | 1:32 PM
are the results good?
what are the results of using the json files?

Apoorv Pandey
5:24 PM
Yea, I took the invoice texts from Bezeichnung

Vincent Ochs
Jan 13, 2026 | 1:33 PM
So generally in JSON under designation.



Some also have IDs, so we need to check with the customer again whether this can always be mapped 1:1, as travel expenses/lunch allowances always come from one vendor, for example.

Show more
mapping 1:1 using vendor id sounds like a good idea too

Apoorv Pandey
5:44 PM
No, what i meant that there wasn't something like "suggested account" for each designation, yk

Vincent Ochs
Jan 13, 2026 | 1:33 PM
We have an overview of the accounts, but they are very detailed.
i have to discuss the NDA again with my customer



Alternatively, I can create another extract that is not critical, if that helps.

Show more
I ran the system, and just translated the results to english and they all made sense

Apoorv Pandey
5:59 PM
[
{
"index": 1,
"quantity": "80 BD",
"item_number": "100036892",
"amount": 1176.0,
"description": "Rapido welded wire ties — 10 cm, 1000 pcs (20 bundles per sack)",
"position": "10",
"unit_price": 14.7,
"supplier": "100036892",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.95,
"explanation": "Primary account for category 'Consumables' (Supplier: 100036892)"
},
{
"index": 2,
"quantity": "30 BD",
"item_number": "100036898",
"amount": 579.0,
"description": "Rapido welded wire ties — 16 cm, 1000 pcs (15 bundles per sack)",
"position": "20",
"unit_price": 19.3,
"supplier": "100036898",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.95,
"explanation": "Primary account for category 'Consumables' (Supplier: 100036898)"
},
{
"index": 3,
"quantity": "12 ST",
"item_number": "100122606",
"amount": 144.0,
"description": "MAXIMUM formwork foam (grey) — 750 ml B3",
"position": "30",
"unit_price": 12.0,
"supplier": "100122606",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.9,
"explanation": "Formwork foam is consumed during application, similar to adhesives and supplies classified as Consumables."
},
{
"index": 4,
"quantity": "34.1 M",
"item_number": "100068986",
"amount": 682.0,
"description": "Zembord 25 formwork panel — 250 mm, length 1.10 m",
"position": "40",
"unit_price": 20.0,
"supplier": "100068986",
"suggested_account": "3000 – Raw Materials",
"category": "Material",
"confidence": 0.9,
"explanation": "Formwork panel used in construction — classified as raw material."
},
{
"index": 5,
"quantity": "1 ST",
"item_number": "500000053",
"amount": 21.0,
"description": "Pallet SBB — 120 x 80 cm",
"position": "999",
"unit_price": 21.0,
"supplier": "500000053",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.8,
"explanation": "A pallet is typically classified as a consumable or packaging/handling supply."
},
{
"index": 6,
"quantity": "40 BD",
"item_number": "100036894",
"amount": 604.0,
"description": "Rapido welded wire ties — 12 cm, 1000 pcs (20 bundles per sack)",
"position": "10",
"unit_price": 15.1,
"supplier": "100036894",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.95,
"explanation": "Primary account for category 'Consumables'."
},
{
"index": 7,
"quantity": "60 BD",
"item_number": "100036896",
"amount": 1068.0,
"description": "Rapido welded wire ties — 14 cm, 1000 pcs (20 bundles per sack)",
"position": "20",
"unit_price": 17.8,
"supplier": "100036896",
"suggested_account": "4200 – Consumables",
"category": "Consumables",
"confidence": 0.95,
"explanation": "Primary account for category 'Consumables'."
},
{
"index": 8,
"quantity": "1.056 TS",
"item_number": "100105956",
"amount": 2101.44,
"description": "Sand-lime brick K 18 — 18 x 14 x 25 cm",
"position": "10",
"unit_price": 1990.0,
"supplier": "100105956",
"suggested_account": "3000 – Raw Materials",
"category": "Material",
"confidence": 0.875,
"explanation": "Building brick used as raw material in construction."
},
{
"index": 9,
"quantity": "1 ST",
"item_number": "200000036",
"amount": 266.11,
"description": "Transport costs",
"position": "20",
"unit_price": 266.11,
"supplier": "200000036",
"suggested_account": "4900 – Transport & Freight Costs",
"category": "Transport",
"confidence": 0.98,
"explanation": "Direct match: term 'Transportkosten' refers to shipping/transport costs."
},
{
"index": 10,
"quantity": "1.2 TS",
"item_number": "100105949",
"amount": 1891.2,
"description": "Sand-lime brick K 15 — 14.5 x 14 x 25 cm",
"position": "30",
"unit_price": 1576.0,
"supplier": "100105949",
"suggested_account": "3000 – Raw Materials",
"category": "Material",
"confidence": 0.875,
"explanation": "Kalksandstein (sand-lime brick) classified as raw material."
}
]

Apoorv Pandey
6:11 PM
so this is basically the first ten from the first json file, i have just translated the results to english for making it easy for me, so I verified them, the original were in german and here it is for you to go through

run_first10.json 
run_first10.json
13 kB
Vincent Ochs
10:06 PM
Attached the very abbreviated chart of accounts, tidied it up a bit.
So everything they have is already quite detailed.

Kontoplan.csv 
Kontoplan.csv
2 kB
Apoorv Pandey
10:12 PM
Thanks a lot. this is for mapping 1:1 using the vendor id right?

u checked the output I sent? they look good to you?

Wednesday, Jan 14
Vincent Ochs
5:44 PM
i think so , yes

Apoorv Pandey
Jan 13, 2026 | 10:12 PM
Thanks a lot. this is for mapping 1:1 using the vendor id right?

let me check

Apoorv Pandey
Jan 13, 2026 | 10:15 PM
u checked the output I sent? they look good to you?

Apoorv Pandey
5:46 PM
Sure.. take ur time

Vincent Ochs
6:11 PM
sorry- im very busy these days

Apoorv Pandey
6:12 PM
No problem boss

Thursday, Jan 15
Vincent Ochs
2:24 PM
can we make use of that?

Apoorv Pandey
Jan 13, 2026 | 10:12 PM
Thanks a lot. this is for mapping 1:1 using the vendor id right?

and in your document you wrote "Passed preliminary tests, ready to test on vast unseen sets and implement feedback loop and re-tests, or supplement with another set of labelled data." -> can we do that now?

Apoorv Pandey
2:26 PM
yea sure

i will start in evening nd send u the results plus entire report on our progress

Vincent Ochs
2:35 PM
thank you!



