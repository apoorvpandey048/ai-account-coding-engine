"""Test initialization."""

# This file makes tests directory a Python package
