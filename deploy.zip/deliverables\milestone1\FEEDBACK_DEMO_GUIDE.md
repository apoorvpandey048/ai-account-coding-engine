# 🔄 Feedback Feature - Demo Guide for Client Meeting

## Overview
The feedback feature is the **learning loop** that makes the system smarter over time. It's how each client builds their own customized AI model.

---

## 🎯 How It Works (Simple Explanation for Vincent)

### 1. **Initial Prediction**
```
Invoice Line: "Transportkosten per LKW nach Zürich"
AI Suggests: 1220 – Materialvorräte (85% confidence)
```

### 2. **User Correction (Feedback)**
```
User (Accountant) sees this is wrong and corrects it:
✅ Actual Account: 4061 – Fremdtransporte
💬 Comment: "This is transport, not materials"
```

### 3. **System Learns**
- Feedback is stored with user context
- Next time similar "transport" items appear → Higher chance of suggesting 4061
- The AI learns YOUR company's specific patterns

---

## 📊 Feedback API Demo

### **Endpoint**: `POST /api/v1/feedback`

### **Request**:
```json
{
  "invoice_text": "Transportkosten per LKW nach Zürich",
  "suggested_account": "1220 – Materialvorräte",
  "actual_account": "4061 – Fremdtransporte",
  "user_id": "accountant_123",
  "comments": "Transport costs should always go to 4061"
}
```

### **Response**:
```json
{
  "status": "success",
  "message": "Feedback recorded successfully",
  "feedback_id": "fb_20260119_001"
}
```

---

## 💡 Key Value Propositions for Vincent

### 1. **Continuous Improvement**
- System gets smarter with every correction
- No need for expensive re-training or consulting
- Your team teaches the AI YOUR way of accounting

### 2. **User-Specific Learning** (Multi-Tenant)
- Each company has different GL account structures
- Feedback creates **YOUR company's custom dataset**
- Company A's feedback doesn't affect Company B's model

### 3. **Audit Trail**
- Every correction is tracked (who, when, why)
- Compliance-friendly: full history of changes
- Can review which accounts were frequently corrected

### 4. **Real Use Cases**

#### **Scenario A: New Vendor**
```
First invoice from "Swiss Rail Transport GmbH"
→ AI guesses 1220 (Material)
→ User corrects to 4061 (Transport)
→ Next invoice from same vendor → AI remembers!
```

#### **Scenario B: Ambiguous Items**
```
"Kleinmengenzuschlag" (Small quantity surcharge)
→ Could be 2004 (Liabilities) or 4980 (Surcharges)
→ User's feedback teaches which one YOUR company prefers
```

#### **Scenario C: Industry-Specific Terms**
```
"Drunterfix mit Aussparung" (Construction formwork)
→ AI learns YOUR construction company's conventions
→ Different from what a manufacturing company might use
```

---

## 🎬 Demo Flow for Meeting

### **Step 1**: Show Initial Suggestion
```bash
curl -X POST https://your-api.azurewebsites.net/api/v1/suggest \
  -H "X-API-Key: dev-key-001" \
  -H "Content-Type: application/json" \
  -d '{
    "line_item": {
      "invoice_text": "Energiezuschlag Januar 2026"
    }
  }'
```

**Output**: 
```json
{
  "suggestions": [
    {
      "account": "1220 – Materialvorräte",
      "confidence": 0.75,
      "explanation": "Classified as material-related charge"
    }
  ]
}
```

### **Step 2**: Show User Correction
```bash
curl -X POST https://your-api.azurewebsites.net/api/v1/feedback \
  -H "X-API-Key: dev-key-001" \
  -H "Content-Type: application/json" \
  -d '{
    "invoice_text": "Energiezuschlag Januar 2026",
    "suggested_account": "1220 – Materialvorräte",
    "actual_account": "2004 – Verbindlichkeiten übr. Betriebsaufwand",
    "user_id": "vincent_company",
    "comments": "Energy surcharges go to operational liabilities"
  }'
```

**Output**:
```json
{
  "status": "success",
  "message": "Feedback recorded successfully",
  "feedback_id": "fb_20260119_001"
}
```

### **Step 3**: Explain the Impact
> "Now, when you or anyone in your company processes another energy surcharge, the AI will remember your preference and suggest account 2004 with higher confidence. Over 3-6 months, the system becomes tailored specifically to your accounting practices."

---

## 🚀 Advanced Features (Optional Talking Points)

### **Per-User Customization**
- Different users can have different "learning profiles"
- Junior accountants get stricter suggestions
- Senior accountants' feedback weighs more heavily

### **Feedback Analytics Dashboard** (Future Enhancement)
```
📊 Weekly Report:
- 150 invoices processed
- 12 corrections submitted
- Top corrected category: Transport (5 times)
- Accuracy improved: 87% → 92%
```

### **Export Your Custom Dataset**
- After 6 months of feedback, you own YOUR training data
- Can export for compliance audits
- Can use for internal training of new staff

---

## ❓ Questions Vincent Might Ask

### Q1: "How long before the system learns our patterns?"
**A**: Typically 20-30 feedback submissions per account category. For common accounts (materials, transport), you'll see improvement within 2-4 weeks of daily use.

### Q2: "What if two accountants disagree on the correct account?"
**A**: System tracks all feedback with user IDs. You can set up approval workflows where senior accountants review junior corrections. Majority rule or role-based weighting can be applied.

### Q3: "Can we see which accounts are most frequently corrected?"
**A**: Yes! Feedback data shows which items are ambiguous. This helps you:
- Update vendor master data
- Refine your chart of accounts
- Train staff on edge cases

### Q4: "Is our feedback data secure and private?"
**A**: Absolutely. Each client's feedback is stored separately (multi-tenant architecture). Your corrections never affect other companies' models. Full encryption at rest and in transit.

---

## 🎤 Closing Pitch

> "Vincent, this isn't just an AI that gives suggestions. It's a **learning partner** that adapts to YOUR business. Every invoice you process makes it smarter. In 6 months, you'll have a custom AI model that knows your company better than any off-the-shelf solution. And the best part? You own the data, the improvements, and the IP."

---

## 📝 Action Items for Meeting
- [ ] Live demo of suggestion API
- [ ] Live demo of feedback API
- [ ] Show feedback.jsonl file (stored data)
- [ ] Discuss integration with their ERP system
- [ ] Discuss pricing model (per API call vs. subscription)
- [ ] Set timeline for pilot program (3-month trial)
